练习一：理解通过make生成执行的过程
1.操作系统镜像文件ucore.img是如何一步一步生成的？
答：ucore.img由两个部分组成，一个是bootblock，一个是内核kernel。
   make的过程主要分为两部分————代码的编译和镜像的生成。
   代码的编译链接：
       首先使用gcc 来将需要的c文件编译成.o目标文件
       再使用ld命令将这些目标文件进行链接，生成可执行文件
       A.和kernel相关的c文件：
        init.c
        readline.c
        stdio.c
        kdebug.c
        kmonitor.c
        panic.c
        clock.c
        console.c
        intr.c
        picirq.c
        trap.c
        trapentry.S
        vectors.S
        pmm.c
        printfmt.c
        string.c
       B.和bootblock相关的c文件：
        bootasm.S
        bootmain.c
        sign.c
   镜像的生成：
       首先通过命令生成一个固定大小的空镜像文件：
       dd if=/dev/zero of=bin/ucore.img count=10000
       然后将bootblock和kernel按照顺序拷贝到空镜像文件中：
       dd if=bin/bootblock of=bin/ucore.img conv=notrunc
       dd if=bin/kernel of=bin/ucore.img seek=1 conv=notrunc
2.一个被系统认为是符合规范的硬盘主引导扇区的特征是什么？
   buf[510] = 0x55;
   buf[511] = 0xAA;
   在sign.c中存在以上两行代码。主引导扇区一共512个字节，其中代码bootblock部分不超过510个字节，扇区的最后
   两个字节是0x55和0xAA。

练习二：使用qemu调试并执行lab1中的软件
   通过读bootasm.S的代码，发现汇编指令有31条，所以预计会有30-40条指令。
   运行make lab1-mon之后，在gdb的界面输入
   x /33i $pc
   可以得到用gdb反汇编的代码如下：
   0x7c00:	cli    
   0x7c01:	cld    
   0x7c02:	xor    %ax,%ax
   0x7c04:	mov    %ax,%ds
   0x7c06:	mov    %ax,%es
   0x7c08:	mov    %ax,%ss
   0x7c0a:	in     $0x64,%al
   0x7c0c:	test   $0x2,%al
   0x7c0e:	jne    0x7c0a
   0x7c10:	mov    $0xd1,%al
   0x7c12:	out    %al,$0x64
   0x7c14:	in     $0x64,%al
   0x7c16:	test   $0x2,%al
   0x7c18:	jne    0x7c14
   0x7c1a:	mov    $0xdf,%al
   0x7c1c:	out    %al,$0x60
   0x7c1e:	lgdtw  0x7c6c
   0x7c23:	mov    %cr0,%eax
   0x7c26:	or     $0x1,%eax
   0x7c2a:	mov    %eax,%cr0
   0x7c2d:	ljmp   $0x8,$0x7c32
   0x7c32:	mov    $0xd88e0010,%eax
   0x7c38:	mov    %ax,%es
   0x7c3a:	mov    %ax,%fs
   0x7c3c:	mov    %ax,%gs
   0x7c3e:	mov    %ax,%ss
   0x7c40:	mov    $0x0,%bp
   0x7c43:	add    %al,(%bx,%si)
   0x7c45:	mov    $0x7c00,%sp
   0x7c48:	add    %al,(%bx,%si)
   0x7c4a:	call   0x7cfe
   0x7c4d:	add    %al,(%bx,%si)
   0x7c4f:  jmp    0x7c4f
   可以看出，gdb显示的指令已经没有了各种标识符，这些标识符都被实际的地址所替代。
       
   发现0x7cfe对应于bootasm.S中的bootmain标识符，所以将断点设置在0x7cfe，查阅之后的代码
   0x7cfe:	pop    %bp
   0x7cff:	ret    
   0x7d00:	mov    0x7de4,%ax
   0x7d03:	add    %al,(%bx,%si)
   0x7d05:	xor    %cx,%cx
   0x7d07:	push   %bp
   0x7d08:	mov    %sp,%bp
   0x7d0a:	push   %si
   0x7d0b:	lea    (%si),%dx
   0x7d0d:	lds    (%bx,%si),%ax
   0x7d0f:	add    %al,(%bx,%si)
   0x7d11:	add    %ah,0x7de0(%bx,%di)
   0x7d15:	add    %al,(%bx,%si)
   0x7d17:	push   %bx
   0x7d18:	call   0x7c70
   可以看出和原来文件中的代码相对应，bootmain 函数中第一步是调用了函数readseg，所以代码首先在进行参数的传递，然后call 0x7c70调用readseg函数。
   
练习三：实模式与保护模式的切换
   1.在bootloader执行的一开始，首先将中断使能关闭，然后将ds，es和ss都设置为0 。
   2.接下来进行A20地址线的开启：

seta20.1:
    inb $0x64, %al                                  # Wait for not busy(8042 input buffer empty).
    testb $0x2, %al
    jnz seta20.1

    movb $0xd1, %al                                 # 0xd1 -> port 0x64
    outb %al, $0x64                                 # 0xd1 means: write data to 8042's P2 port

seta20.2:
    inb $0x64, %al                                  # Wait for not busy(8042 input buffer empty).
    testb $0x2, %al
    jnz seta20.2

    movb $0xdf, %al                                 # 0xdf -> port 0x60
    outb %al, $0x60                                 # 0xdf = 11011111, means set P2's A20 bit(the 1 bit) to 1
    
    3.通过这两步设置，最终将P2的A20端口设置为1
    
    4.接下来使用一个bootstrap全局描述符表，修改寄存器cr0的值为0x1,进入保护模式32位的代码段。

.code32                                             # Assemble for 32-bit mode
protcseg:
    # Set up the protected-mode data segment registers
    movw $PROT_MODE_DSEG, %ax                       # Our data segment selector
    movw %ax, %ds                                   # -> DS: Data Segment
    movw %ax, %es                                   # -> ES: Extra Segment
    movw %ax, %fs                                   # -> FS
    movw %ax, %gs                                   # -> GS
    movw %ax, %ss                                   # -> SS: Stack Segment

    # Set up the stack pointer and call into C. The stack region is from 0--start(0x7c00)
    movl $0x0, %ebp
    movl $start, %esp
    call bootmain
    
    5.最后在32位模式下进行段和栈的设置，跳转到bootmain函数去执行。
    
练习四：分析bootloader加载ELF格式的OS的过程
    在bootmain函数的一开始，bootloader将ELF格式的OS的第一页加载了进来。

void
bootmain(void) {
    // read the 1st page off disk
    readseg((uintptr_t)ELFHDR, SECTSIZE * 8, 0);

    // is this a valid ELF?
    if (ELFHDR->e_magic != ELF_MAGIC) {
        goto bad;
    }

    struct proghdr *ph, *eph;

    // load each program segment (ignores ph flags)
    ph = (struct proghdr *)((uintptr_t)ELFHDR + ELFHDR->e_phoff);
    eph = ph + ELFHDR->e_phnum;
    for (; ph < eph; ph ++) {
        readseg(ph->p_va & 0xFFFFFF, ph->p_memsz, ph->p_offset);
    }

    // call the entry point from the ELF header
    // note: does not return
    ((void (*)(void))(ELFHDR->e_entry & 0xFFFFFF))();

bad:
    outw(0x8A00, 0x8A00);
    outw(0x8A00, 0x8E00);

    /* do nothing */
    while (1);
}

    相关的函数:readseg，参数有三个：虚拟地址，大小，偏移量。
    在这个函数中先设置好起始的虚拟地址，然后用for循环一块一块地读入。
    读入一块（sectsize）需要函数readsect：
static void
readsect(void *dst, uint32_t secno) {
    // wait for disk to be ready
    waitdisk();

    outb(0x1F2, 1);                         // count = 1
    outb(0x1F3, secno & 0xFF);
    outb(0x1F4, (secno >> 8) & 0xFF);
    outb(0x1F5, (secno >> 16) & 0xFF);
    outb(0x1F6, ((secno >> 24) & 0xF) | 0xE0);
    outb(0x1F7, 0x20);                      // cmd 0x20 - read sectors

    // wait for disk to be ready
    waitdisk();

    // read a sector
    insl(0x1F0, dst, SECTSIZE / 4);
}
    函数中的注释也清楚地显示了读一个sector的步骤。
    在读入完成之后，bootmain还会对这个读入进来的第一页进行检查。然后再将程序段一段一段地加载进来。
    
    最后调用在ELF头中记录的内核入口。
    
练习五：函数调用栈的追踪
    按照注释中的提示，一步一步地翻译伪代码即可。
    和视频中的显示大致相同。
    ebp:00007bf8, eip:00007d68, args:c031fcfa c08ed88e 64e4d08e fa7502a8 
    这些显示的是程序调用bootmain函数时的ebp，eip值以及传入的参数。
    
练习六：完善中断初始化和处理    
    中断向量表中一个表项占多少个字节，其中哪几位代表中断处理代码的入口？
    答：读vector.S文件，可以看出每一项都是long类型，所以是8个字节。0-1和6-7字节都是位移，2-3是选择子。
    这三者组成中断处理入口。
    
    除了系统调用是用户态的，T_SWITCH_TOK也是，因为从用户态切换回内核态自然也是需要是用户态的。
    在初始化中就要添加如下两行：
    SETGATE(idt[T_SWITCH_TOK], 0, GD_KTEXT, __vectors[T_SWITCH_TOK], DPL_USER);
    SETGATE(idt[T_SYSCALL], 1, GD_KTEXT, __vectors[T_SYSCALL], DPL_USER);       
        
